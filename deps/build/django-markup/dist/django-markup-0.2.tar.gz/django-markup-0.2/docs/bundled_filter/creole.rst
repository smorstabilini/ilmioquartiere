.. _filter-creole:

Creole Wiki Syntax
==================

- Filter name: ``creole``
- Pypi package: ``Creopleparser``

Creoleparser_ is a Python implementation of a parser for the Creole_ wiki markup
language.

.. _Creoleparser: http://code.google.com/p/creoleparser/
.. _Creole: http://wikicreole.org/wiki/Creole1.0