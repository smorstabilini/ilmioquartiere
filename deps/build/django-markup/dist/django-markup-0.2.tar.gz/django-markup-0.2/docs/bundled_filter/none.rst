None (no processing)
====================

- Filter name: ``none``

This is the most simplest filter. It returns the text as is.