=============
django-markup
=============

This app is a generic way to provide filters that convert text into html.

The documentation is available with this package in the ``docs/`` folder or
online under this url: http://docs.mahner.org/django-markup/