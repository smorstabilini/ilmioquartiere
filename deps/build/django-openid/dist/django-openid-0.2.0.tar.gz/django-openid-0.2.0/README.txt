django_openid
=============

A new take on Django/OpenID integration, making extensive use of class-based 
views.

Caution: Work in Progress

It's not ready yet! However, you are welcome to dive in to the code or take a 
look at the in-progress documentation in django_openid/docs (which can be 
built using Sphinx).
